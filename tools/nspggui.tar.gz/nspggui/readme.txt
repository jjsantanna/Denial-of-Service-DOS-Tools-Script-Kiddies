This nspggui is just a simple perl script to implement GUI for nspg.

How to build?

This package will need next packages:
1) Switch-2.14 from CPAN
2) linux dialog package for terminal based GUI
   for debian and ubuntu system
	$ sudo apt-get install dialog
3) nspg is already installed on system

Installing nspggui
4) copy all scripts recursively into /usr/local/bin

How to run?
$ sudo /usr/local/bin/nspggui
