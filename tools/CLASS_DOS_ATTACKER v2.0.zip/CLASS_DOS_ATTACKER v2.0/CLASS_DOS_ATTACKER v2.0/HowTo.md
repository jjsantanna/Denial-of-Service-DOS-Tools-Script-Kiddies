#How to Use

Requirements : OS LINUX based
 
 Tested and working with Python 2.7 (2.7.15-3) including module Tkinter 8.6 und scapy 2.4 (2.4.0-2)
 
	just run these commands to install it:
	
	- sudo apt-get install python2.7
	- sudo apt-get install python-tk
	- sudo apt-get install python-scapy

    for the "WIFI DEAUTH" attack you need to have airodump-ng (you cann avoid having it when you already have all the information about the AP :
    AP Mac; AP Cannal). Airdodump-ng is included in Aircrack-ng.
	
	- sudo apt-get install aircrack-ng
    
LAUNCH:

python launch_class_dos_attacker_graphique_graphique.py

Choose one attack and follow the instructions to launch it
