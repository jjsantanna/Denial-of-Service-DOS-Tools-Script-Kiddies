import arp_spoof_graphique

if __name__ == "__main__":
	app=arp_spoof_graphique.test_fenetre(None)
	app.title("ARP CACHE POISONING")
	app.mainloop()
