
class Sortie(object):
    '''A general class for redirecting I/O to this Text widget.'''
    def __init__(self,text_area):
        self.text_area = text_area
	#self.terminal=sys.sdtout
