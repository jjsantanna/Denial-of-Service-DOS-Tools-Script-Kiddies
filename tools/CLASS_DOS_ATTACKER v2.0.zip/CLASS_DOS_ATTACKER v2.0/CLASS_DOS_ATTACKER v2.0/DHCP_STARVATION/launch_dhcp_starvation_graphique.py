import dhcp_starvation_graphique

if __name__ == "__main__":
	app=dhcp_starvation_graphique.test_fenetre(None)
	app.title("DHCP STARVATION")
	app.mainloop()
