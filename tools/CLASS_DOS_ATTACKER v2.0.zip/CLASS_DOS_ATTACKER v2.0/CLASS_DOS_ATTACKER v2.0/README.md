# CLASS_DOS_ATTACKER
A Software for educational purpose of learning and implementing Denial of Service Attacks in Python.

The CLASS_DOS_ATTACKER Project is basically just a small tool to test basic denial of service attacks, it is delivered for 5 attacks :

  -  ARP Cache poisonning

   - DHCP Starvation

  -  ICMP FLOOD

  -  TCP SYNFLOOD

  -  WIFI DEAUTHENTICATION

The code is not really professional, as it was hastily written in order to test these attacks

the source code is therefore available for Adding/Modifying/Updating an attack

the application was initially written in French but was later tranlated in english in order to be publish.

otherwise, it already allows a good handling of these 5 DOS attacks.

Contact : stevelaclasse@gmail.com
