import class_dos_attacker_graphique

if __name__ == "__main__":
	app=class_dos_attacker_graphique.test_fenetre(None)
	app.title("CLASS DOS ATTACKER")
	app.mainloop()
