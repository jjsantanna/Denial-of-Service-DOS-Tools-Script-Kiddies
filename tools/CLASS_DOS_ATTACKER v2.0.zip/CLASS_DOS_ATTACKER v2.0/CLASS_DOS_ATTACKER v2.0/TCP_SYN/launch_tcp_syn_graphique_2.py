import tcp_syn_graphique_2

if __name__ == "__main__":
	app=tcp_syn_graphique_2.test_fenetre(None)
	app.title("TCP SYNFLOOD")
	app.mainloop()
