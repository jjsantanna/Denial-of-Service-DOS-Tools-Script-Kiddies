import kick_deauth_graphique

if __name__ == "__main__":
	app=kick_deauth_graphique.test_fenetre(None)
	app.title("WIFI DEAUTHENTIFICATION")
	app.mainloop()
