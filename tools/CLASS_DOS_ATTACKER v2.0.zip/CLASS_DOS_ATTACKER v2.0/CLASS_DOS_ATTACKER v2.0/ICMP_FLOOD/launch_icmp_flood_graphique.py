import icmp_flood_graphique

if __name__ == "__main__":
	app=icmp_flood_graphique.test_fenetre(None)
	app.title("ICMP FLOOD")
	app.mainloop()
